// assignment2_1.js
// calls createTestFile();

const createTestFile = require('./Assignment2_2.js');

createTestFile.createTestFile;


//ENDFILE
